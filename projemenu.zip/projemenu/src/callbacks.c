#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include <stdlib.h>
#include <string.h>

int x = 1;
int supp = 0;
void
on_FB_button_ajout_gestion_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* input;
GtkWidget* output;
GtkWidget* FB_window1_gestion;
FB_window1_gestion=lookup_widget(button,"FB_window1_gestion");
gtk_widget_destroy(FB_window1_gestion);
GtkWidget* FB_window4_ajout;
FB_window4_ajout=create_FB_window4_ajout();
gtk_widget_show(FB_window4_ajout);
}


void
on_FB_button_modifier_gestion_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* input;
GtkWidget* output;
GtkWidget* FB_window1_gestion;
FB_window1_gestion=lookup_widget(button,"FB_window1_gestion");
gtk_widget_destroy(FB_window1_gestion);
GtkWidget* FB_window5_modif;
FB_window5_modif=create_FB_window5_modif();
gtk_widget_show(FB_window5_modif);

}


void
on_FB_button_supprimer_gestion_clicked (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* input;
GtkWidget* output;
GtkWidget* FB_window1_gestion;
FB_window1_gestion=lookup_widget(button,"FB_window1_gestion");
gtk_widget_destroy(FB_window1_gestion);
GtkWidget* FB_window3_supp;
FB_window3_supp=create_FB_window3_supp();
gtk_widget_show(FB_window3_supp);
}


void
on_FB_button_meilleur_menu_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *FB_window1_gestion;
GtkWidget *FB_window_meill;
GtkWidget *FB_treeview4;

FB_window1_gestion=lookup_widget(button,"FB_window1_gestion");
gtk_widget_destroy(FB_window1_gestion);
FB_window_meill=lookup_widget(button,"FB_window_meill");
FB_window_meill=create_FB_window_meill();
gtk_widget_show(FB_window_meill);
FB_treeview4=lookup_widget(FB_window_meill,"FB_treeview3");
dechets_menu(FB_treeview4);
//afficher_etage(treeview4);
remove(FB_treeview4);
gtk_widget_destroy(FB_window1_gestion);
}


void
on_FB_button_rechercher_gestion_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* input;
GtkWidget* output;
GtkWidget* FB_window1_gestion;
FB_window1_gestion=lookup_widget(button,"FB_window1_gestion");
gtk_widget_destroy(FB_window1_gestion);
GtkWidget* FB_window2_liste;
FB_window2_liste=create_FB_window2_liste();
gtk_widget_show(FB_window2_liste);
}


void
on_FB_button_retour_liste_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* input;
GtkWidget* output;
GtkWidget* FB_window2_liste;
GtkWidget *FB_treeview1;

FB_window2_liste=lookup_widget(button,"FB_window2_liste");
gtk_widget_destroy(FB_window2_liste);
GtkWidget* FB_window1_gestion;
FB_window1_gestion=create_FB_window1_gestion();
gtk_widget_show(FB_window1_gestion);
FB_treeview1 = lookup_widget(FB_window1_gestion,"FB_treeview1");
afficher_menu(FB_treeview1);
}


void
on_FB_button_rechercher_liste_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *FB_window2_liste;
	GtkWidget *FB_treeview3;
	GtkWidget *FB_entry1;


	FB_window2_liste = lookup_widget(button,"FB_window2_liste");
	FB_treeview3 = lookup_widget(FB_window2_liste,"FB_treeview3");
	FB_entry1 = lookup_widget(FB_window2_liste,"FB_entry1");

	rechercher_menu(FB_treeview3, gtk_entry_get_text(GTK_ENTRY(FB_entry1)));
}


void
on_checkbutton_supp_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
		supp = 1;
	} else {
		supp = 0;
	}
}


void
on_FB_button_supprimer_supprission_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *FB_window3_supp;
	GtkWidget *FB_entry2;
	GtkWidget *FB_label_supp_message;

	FB_window3_supp = lookup_widget(button,"FB_window3_supp");
	FB_entry2 = lookup_widget(FB_window3_supp,"FB_entry2");
	FB_label_supp_message = lookup_widget(FB_window3_supp,"FB_label_supp_message");

	if(supp == 1){
		supprimer_menu(gtk_entry_get_text(GTK_ENTRY(FB_entry2)));
		gtk_label_set_text(GTK_LABEL(FB_label_supp_message),"menu supprimé avec succée!");
		gtk_widget_show(FB_label_supp_message);
	}else if(supp == 0){
		gtk_label_set_text(GTK_LABEL(FB_label_supp_message),"Cocher la confirmation de supprission!");
		gtk_widget_show(FB_label_supp_message);
	}
}


void
on_FB_button_retour_suppression_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* input;
GtkWidget* output;
GtkWidget* FB_window3_supp;
GtkWidget *FB_treeview1;
FB_window3_supp=lookup_widget(button,"FB_window3_supp");
gtk_widget_destroy(FB_window3_supp);
GtkWidget* FB_window1_gestion;
FB_window1_gestion=create_FB_window1_gestion();
gtk_widget_show(FB_window1_gestion);
FB_treeview1 = lookup_widget(FB_window1_gestion,"FB_treeview1");
afficher_menu(FB_treeview1);
}


void
on_radiobutton_dejeuner_ajout_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=2;
}
}


void
on_radiobutton_diner_ajout_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=3;
}
}


void
on_FB_button_ajouter_ajout_activate    (GtkButton       *button,
                                        gpointer         user_data)
{
menu m;
   GtkWidget *id;
   GtkWidget *type;
   GtkWidget *entree;
   GtkWidget *plat_principal;
   GtkWidget *dessert;
   GtkWidget *Jour;
   GtkWidget *Mois;
   GtkWidget *Annee;
   GtkWidget *FB_Comboboxqd;
   GtkWidget *FB_label_ajut_reussite; 
   int ajout,verif;
   char text[200];

  
  
FB_label_ajut_reussite = lookup_widget(button,"FB_label_ajut_reussite");
id=lookup_widget(button,"FB_entry_id_ajout");
strcpy(m.id,gtk_entry_get_text(GTK_ENTRY(id)));
entree=lookup_widget(button,"FB_entry3");
strcpy(m.entree,gtk_entry_get_text(GTK_ENTRY(entree)));
plat_principal=lookup_widget(button,"FB_entry4");
strcpy(m.plat_principal,gtk_entry_get_text(GTK_ENTRY(plat_principal)));
dessert=lookup_widget(button,"FB_entry5");
strcpy(m.dessert,gtk_entry_get_text(GTK_ENTRY(dessert)));
/////////////////////////////////////////////////////////
Jour=lookup_widget(button,"FB_spinbutton1_ajout");
Mois=lookup_widget(button,"FB_spinbutton2_ajout");
Annee=lookup_widget(button,"FB_spinbutton3_ajout");
m.Jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
m.Mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
m.Annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));
///////////////////////////////////////////////////////////
FB_Comboboxqd=lookup_widget(button,"FB_combobox1");
strcpy(m.qd,gtk_combo_box_get_active_text(GTK_COMBO_BOX(FB_Comboboxqd)));
///////////////////////////////////////////////////////////////////////////
if(x==1)
{strcpy(m.type,"p-dejeuner");}
else
if(x==2)
{strcpy(m.type,"dejeuner");}
else
if(x==3)
{strcpy(m.type,"diner");}

ajouter_menu(m);
gtk_widget_show(FB_label_ajut_reussite);
}


void
on_FB_button_retour_ajout_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* input;
GtkWidget* output;
GtkWidget* FB_window4_ajout;
GtkWidget *FB_treeview1;
FB_window4_ajout=lookup_widget(button,"FB_window4_ajout");
gtk_widget_destroy(FB_window4_ajout);
GtkWidget* FB_window1_gestion;
FB_window1_gestion=create_FB_window1_gestion();
gtk_widget_show(FB_window1_gestion);
FB_treeview1 = lookup_widget(FB_window1_gestion,"FB_treeview1");
afficher_menu(FB_treeview1);
}


void
on_radiobutton_p_dejeuner_ajout_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=1;
}
}


void
on_radiobutton_diner_modif_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=3;
}
}


void
on_radiobutton_dejeuner_modif_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=2;
}
}


void
on_radiobutton_p_dejeuner_moodif_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=1;
}
}


void
on_FB_button_modifier_modification_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
{menu m;
   GtkWidget *id;
   GtkWidget *type;
   GtkWidget *entree;
   GtkWidget *plat_principal;
   GtkWidget *dessert;
   GtkWidget *Jour;
   GtkWidget *Mois;
   GtkWidget *Annee;
   GtkWidget *Comboboxqd ;
   
   //char text[200];

  
  
GtkWidget *FB_window5_modif;

FB_window5_modif=lookup_widget(button,"FB_window5_modif");
id=lookup_widget(button,"FB_entry_id_modif");
strcpy(m.id,gtk_entry_get_text(GTK_ENTRY(id)));
entree=lookup_widget(button,"FB_entry6");
strcpy(m.entree,gtk_entry_get_text(GTK_ENTRY(entree)));
plat_principal=lookup_widget(button,"FB_entry7");
strcpy(m.plat_principal,gtk_entry_get_text(GTK_ENTRY(plat_principal)));
dessert=lookup_widget(button,"FB_entry8");
strcpy(m.dessert,gtk_entry_get_text(GTK_ENTRY(dessert)));
/////////////////////////////////////////////////////////
Jour=lookup_widget(button,"FB_spinbutton4_modif");
Mois=lookup_widget(button,"FB_spinbutton5_modif");
Annee=lookup_widget(button,"FB_spinbutton6_modif");
m.Jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
m.Mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
m.Annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));
///////////////////////////////////////////////////////////
Comboboxqd=lookup_widget(button,"combobox2");
strcpy(m.qd,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Comboboxqd)));
///////////////////////////////////////////////////////////////////////////
if(x==1)
{strcpy(m.type,"p-dejeuner");}
else
if(x==2)
{strcpy(m.type,"dejeuner");}
else
if(x==3)
{strcpy(m.type,"diner");}

modifier_menu(m);
}
}


void
on_FB_button_retour_modification_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* input;
GtkWidget* output;
GtkWidget* FB_window5_modif;
GtkWidget *FB_treeview1;
FB_window5_modif=lookup_widget(button,"FB_window5_modif");
gtk_widget_destroy(FB_window5_modif);
GtkWidget* FB_window1_gestion;
FB_window1_gestion=create_FB_window1_gestion();
gtk_widget_show(FB_window1_gestion);
FB_treeview1 = lookup_widget(FB_window1_gestion,"FB_treeview1");
afficher_menu(FB_treeview1);
}


void
on_FB_treeview4_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar *jour1;
	gchar *type1; 
	gchar *valeur; 
        dechets d;                                 
	FILE *f=NULL;


	GtkTreeModel *tree_model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(tree_model,&iter,path))
	{gtk_tree_model_get (GTK_LIST_STORE(tree_model),&iter,0,&jour1,1,&type1,2,&valeur,-1);


	d.jour1=jour1;
        d.type1=type1;
        strcpy(d.valeur,valeur);
	afficher_dechets(treeview);
	}
}


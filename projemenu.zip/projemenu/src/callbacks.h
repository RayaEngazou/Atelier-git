#include <gtk/gtk.h>


void
on_FB_button_ajout_gestion_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_FB_button_modifier_gestion_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_FB_button_supprimer_gestion_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_FB_button_meilleur_menu_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_FB_button_rechercher_gestion_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_FB_button_retour_liste_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_FB_button_rechercher_liste_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton_supp_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_FB_button_supprimer_supprission_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_FB_button_retour_suppression_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_dejeuner_ajout_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_diner_ajout_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_FB_button_ajouter_ajout_activate    (GtkButton       *button,
                                        gpointer         user_data);

void
on_FB_button_retour_ajout_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_p_dejeuner_ajout_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_diner_modif_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_dejeuner_modif_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_p_dejeuner_moodif_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_FB_button_modifier_modification_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_FB_button_retour_modification_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_FB_treeview4_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
